import React from 'react'
import Home from './Home'

function Jewellery() {



  return (
   <>
     <Home/>
   </>
  )
}

export default Jewellery

