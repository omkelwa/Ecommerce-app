import React from 'react'
import Home from './Home'

function Mens() {
  return (
    <>
      <Home />
    </>
  )
}

export default Mens
