import React from 'react'
import HeroSection from '../components/HeroSection'
import ProductContainer from '../components/ProductContainer'


function Home() {



  return (
    <>
    <HeroSection/>
    <ProductContainer />
    </>
  )
}

export default Home