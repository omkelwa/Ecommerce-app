import React from 'react'

import Home from './Home'


function Electronics() {

  return (
    <>
      <Home />
    </>
  )
}

export default Electronics

