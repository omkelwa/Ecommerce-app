import React from 'react'
import Home from './Home'

function Womens() {
  return (
    <>
      <Home />
    </>
  )
}

export default Womens
